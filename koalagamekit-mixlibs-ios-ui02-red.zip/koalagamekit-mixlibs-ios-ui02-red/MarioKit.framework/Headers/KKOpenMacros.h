#ifndef KKOpenMacros_h
#define KKOpenMacros_h


// 对外可见的宏
#define Koala cjeZcN7aisV_RtUX
#define KKRole ihjBPmeGEbdr2A5kJi1
#define KKOrder qfajvrDn7qytg
#define KKUser d0LOu_h7Nk2gdXy
#define KKConfig XdnAGzaKhp8RtBcv3l0
#define KKResult OlaBnCPwpAdRcmh_
#define kgk_settleBillWithOrder BOzJre8EAbkWQ4htUZs
#define kgk_postRoleInfoWithModel SpZ7SLwE5a9CU
#define kgk_switchAccounts uGTbENgeCq5V9Wr
#define kgk_openLog AfQ1Z2dPTpxv0RsWu
#define kgk_loginWithViewController qwa2kjxJtpzOYy5HA4
#define kgk_initGameKitWithCompletionHandler UUKGbgte28ihBYZRWP7
#define kgk_demo_setPkver uUWB5Hmz4DwacspX09kel

#endif
