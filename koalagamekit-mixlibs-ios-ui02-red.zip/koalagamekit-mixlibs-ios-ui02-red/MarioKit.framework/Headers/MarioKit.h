//
//  MarioKit.h
//  MarioKit
//
//  Created by 李一贤 on 2018/7/25.
//  Copyright © 2018年 李一贤. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MarioKit/Koala.h>
//! Project version number for MarioKit.
FOUNDATION_EXPORT double MarioKitVersionNumber;

//! Project version string for MarioKit.
FOUNDATION_EXPORT const unsigned char MarioKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MarioKit/PublicHeader.h>


